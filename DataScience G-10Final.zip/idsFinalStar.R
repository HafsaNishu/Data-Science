

library(rvest)      # Web scraping
library(dplyr)      # Data manipulation
library(stringr)    # Text extraction
library(ggplot2)
library(corrplot)   
library(car)        



# Create empty data frame
all_laptops_data <- data.frame()
total_pages <- 15

for (page_num in 1:total_pages) {
  
  cat("Scraping page", page_num, "of", total_pages, "...\n")
  url <- paste0("https://www.startech.com.bd/laptop-notebook/laptop?page=", page_num)
  Sys.sleep(2)
  webpage <- tryCatch({
    read_html(url)
  }, error = function(e) {
    cat("  Error loading page", page_num, "- skipping\n")
    return(NULL)
  })
  
  if(is.null(webpage)) next
  
  product_containers <- webpage %>%
    html_nodes(".p-item-details")
  
  if(length(product_containers) == 0) {
    cat("  No products found on page", page_num, "- stopping\n")
    break
  }
  
  # Extract data
  laptop_names <- product_containers %>%
    html_node(".p-item-name a") %>% 
    html_text(trim = TRUE)
  
  laptop_descriptions <- product_containers %>%
    html_node(".short-description") %>%
    html_text(trim = TRUE)
  
  laptop_prices <- product_containers %>%
    html_node(".p-item-price span:first-child") %>%
    html_text(trim = TRUE)
  
  # Create page data frame
  page_data <- data.frame(
    Product_Name = laptop_names,
    Description = laptop_descriptions,
    Price_BDT = laptop_prices,
    stringsAsFactors = FALSE
  )
  
  # Append to main dataset
  all_laptops_data <- bind_rows(all_laptops_data, page_data)
  
  cat("  Found:", nrow(page_data), "products\n")
}


# Save raw scraped data
write.csv(all_laptops_data, "startech_laptops_raw.csv", row.names = FALSE)

# ============================================================================
# 3. DATA UNDERSTANDING AND EXPLORATION


# Dataset structure

str(all_laptops_data)
cat("\nDimensions:", dim(all_laptops_data), "\n")

# Check missing values
colSums(is.na(all_laptops_data))

# Summary of raw data
print(head(all_laptops_data$Price_BDT, 10))

# ============================================================================
# 4. DATA PREPROCESSING

df <- all_laptops_data

# 4.1 Clean Price - Remove currency symbol and commas
df <- df %>%
  mutate(
    Price_Numeric = as.numeric(gsub("[৳,]", "", Price_BDT))
  )

# Count rows lost due to non-numeric prices
na_count <- sum(is.na(df$Price_Numeric))
cat("Rows with non-numeric prices (Upcoming/Out of Stock):", na_count, "\n")

# 4.2 Feature Engineering - Extract Hardware Specifications

df <- df %>%
  mutate(
    # Extract RAM (looks for patterns like "8GB", "16GB DDR4")
    RAM_GB = as.numeric(str_extract(Description, "(?i)\\d+(?=\\s*(GB|G\\s*B|LPDDR|DDR|RAM))")),
    
    # Extract Storage (looks for "256GB", "512GB", "1TB")
    Storage_Raw = as.numeric(str_extract(Description, "(?i)\\d+(?=\\s*(GB|SSD|HDD))")),
    Storage_Unit = str_extract(Description, "(?i)(GB|TB)(?=\\s*(SSD|HDD))"),
    
    # Extract Display Size (looks for '14"', '15.6 inch', etc.)
    Display_Size = as.numeric(str_extract(Description, "\\d+(\\.\\d+)?(?=(\"|\\s*inch))")),
    
    # Extract Processor Information
    Processor_Intel = as.numeric(grepl("Intel", Description, ignore.case = TRUE)),
    Processor_AMD = as.numeric(grepl("AMD|Ryzen", Description, ignore.case = TRUE)),
    Processor_i3 = as.numeric(grepl("i3[^0-9]", Description, ignore.case = TRUE)),
    Processor_i5 = as.numeric(grepl("i5[^0-9]", Description, ignore.case = TRUE)),
    Processor_i7 = as.numeric(grepl("i7[^0-9]", Description, ignore.case = TRUE)),
    Processor_i9 = as.numeric(grepl("i9[^0-9]", Description, ignore.case = TRUE)),
    
    # Extract Features
    Has_Backlit = as.numeric(grepl("Backlit Keyboard", Description, ignore.case = TRUE)),
    Has_TypeC = as.numeric(grepl("Type-C|USB-C|USBC", Description, ignore.case = TRUE)),
    Has_Touch = as.numeric(grepl("Touch Screen|Touchscreen|Touch", Description, ignore.case = TRUE)),
    Has_Fingerprint = as.numeric(grepl("Fingerprint", Description, ignore.case = TRUE)),
    Has_GPU = as.numeric(grepl("RTX|GTX|Graphics|GPU", Description, ignore.case = TRUE))
  )

# 4.3 Convert Storage from TB to GB
df <- df %>%
  mutate(
    Storage_GB = ifelse(!is.na(Storage_Unit) & toupper(Storage_Unit) == "TB", 
                        Storage_Raw * 1024, Storage_Raw)
  )

# 4.4 Create Processor Category
df <- df %>%
  mutate(
    Processor_Category = case_when(
      Processor_i9 == 1 ~ "Core i9",
      Processor_i7 == 1 ~ "Core i7",
      Processor_i5 == 1 ~ "Core i5",
      Processor_i3 == 1 ~ "Core i3",
      Processor_AMD == 1 ~ "AMD Ryzen",
      Processor_Intel == 1 ~ "Intel Other",
      TRUE ~ "Unknown"
    )
  )

# 4.5 Clean the dataset - Remove rows with missing critical values
df_clean <- df %>%
  filter(
    !is.na(Price_Numeric),           # Valid price
    !is.na(RAM_GB),                  # Has RAM info
    !is.na(Storage_GB),              # Has storage info
    Price_Numeric > 10000,           # Remove unrealistically low prices
    Price_Numeric < 500000           # Remove outliers (price > 5 lakh)
  )


cat("Rows remaining:", nrow(df_clean), "\n")
cat("Price range:", min(df_clean$Price_Numeric), "-", max(df_clean$Price_Numeric), "BDT\n")

# Save processed data
write.csv(df_clean, "laptops_processed.csv", row.names = FALSE)

# ============================================================================
# 5. EXPLORATORY DATA ANALYSIS (EDA)

if(!dir.exists("plots")) dir.create("plots")

# 5.1 Summary Statistics
summary(df_clean[c("Price_Numeric", "RAM_GB", "Storage_GB", "Display_Size")])

# 5.2 Price Distribution Histogram
p1 <- ggplot(df_clean, aes(x = Price_Numeric)) +
  geom_histogram(fill = "steelblue", color = "white", bins = 25, alpha = 0.8) +
  geom_vline(aes(xintercept = median(Price_Numeric)), color = "red", linetype = "dashed", linewidth = 1) +
  geom_vline(aes(xintercept = mean(Price_Numeric)), color = "darkgreen", linetype = "dotted", linewidth = 1) +
  labs(
    title = "Distribution of Laptop Prices",
    subtitle = paste("Median:", median(df_clean$Price_Numeric), "BDT | Mean:", round(mean(df_clean$Price_Numeric), 0), "BDT"),
    x = "Price (BDT)", 
    y = "Count"
  ) +
  scale_x_continuous(labels = scales::comma) +
  theme_minimal()
print(p1)
ggsave("plots/1_price_distribution.png", p1, width = 10, height = 6)
cat("Saved: plots/1_price_distribution.png\n")

# 5.3 Boxplot: Price by RAM
p2 <- ggplot(df_clean, aes(x = as.factor(RAM_GB), y = Price_Numeric, fill = as.factor(RAM_GB))) +
  geom_boxplot() +
  stat_summary(fun = "mean", geom = "point", shape = 23, size = 3, fill = "white") +
  labs(
    title = "Price Distribution by RAM Capacity",
    x = "RAM (GB)", 
    y = "Price (BDT)",
    fill = "RAM"
  ) +
  scale_y_continuous(labels = scales::comma) +
  theme_minimal() +
  theme(legend.position = "none")

print(p2)
ggsave("plots/2_price_by_ram.png", p2, width = 10, height = 6)
cat("Saved: plots/2_price_by_ram.png\n")

# 5.4 Boxplot: Price by Processor
p3 <- ggplot(df_clean, aes(x = reorder(Processor_Category, Price_Numeric, FUN = median), 
                           y = Price_Numeric, fill = Processor_Category)) +
  geom_boxplot() +
  coord_flip() +
  labs(
    title = "Price Distribution by Processor Type",
    x = "Processor", 
    y = "Price (BDT)"
  ) +
  scale_y_continuous(labels = scales::comma) +
  theme_minimal() +
  theme(legend.position = "none")
print(p3)
ggsave("plots/3_price_by_processor.png", p3, width = 10, height = 6)
cat("Saved: plots/3_price_by_processor.png\n")

# 5.5 Scatter Plot: RAM vs Price
p4 <- ggplot(df_clean, aes(x = RAM_GB, y = Price_Numeric)) +
  geom_point(alpha = 0.5, color = "darkblue") +
  geom_smooth(method = "lm", color = "red", se = TRUE) +
  labs(
    title = "Relationship between RAM and Price",
    x = "RAM (GB)", 
    y = "Price (BDT)"
  ) +
  scale_y_continuous(labels = scales::comma) +
  theme_minimal()

print(p4)
ggsave("plots/4_ram_vs_price.png", p4, width = 10, height = 6)
cat("Saved: plots/4_ram_vs_price.png\n")

# 5.6 Scatter Plot: Storage vs Price
p5 <- ggplot(df_clean, aes(x = Storage_GB, y = Price_Numeric)) +
  geom_point(alpha = 0.5, color = "darkgreen") +
  geom_smooth(method = "loess", color = "red", se = TRUE) +
  labs(
    title = "Relationship between Storage and Price",
    x = "Storage (GB)", 
    y = "Price (BDT)"
  ) +
  scale_x_log10() +
  scale_y_continuous(labels = scales::comma) +
  theme_minimal()

print(p5)
ggsave("plots/5_storage_vs_price.png", p5, width = 10, height = 6)
cat("Saved: plots/5_storage_vs_price.png\n")

# 5.7 Correlation Heatmap
numeric_vars <- df_clean[, c("Price_Numeric", "RAM_GB", "Storage_GB", "Display_Size")]
cor_matrix <- cor(numeric_vars, use = "complete.obs")

png("plots/6_correlation_heatmap.png", width = 800, height = 600)
corrplot(cor_matrix, method = "number", type = "upper", 
         tl.col = "black", tl.cex = 1.2, number.cex = 1.2,
         title = "Correlation Matrix of Hardware Features", mar = c(0,0,2,0))
dev.off()
cat("Saved: plots/6_correlation_heatmap.png\n")

# ============================================================================
# 6. MODELING AND ANALYSIS

# 6.1 Train-Test Split (80-20%)
set.seed(42)
train_indices <- sample(1:nrow(df_clean), size = 0.8 * nrow(df_clean))
train_data <- df_clean[train_indices, ]
test_data <- df_clean[-train_indices, ]

cat("Training set:", nrow(train_data), "samples (80%)\n")
cat("Testing set:", nrow(test_data), "samples (20%)\n")

# 6.2 Model 1: Simple Linear Regression (Baseline)
model1 <- lm(Price_Numeric ~ RAM_GB, data = train_data)
summary(model1)

# 6.3 Model 2: Multiple Linear Regression (RAM + Storage)
model2 <- lm(Price_Numeric ~ RAM_GB + Storage_GB, data = train_data)
summary(model2)

# 6.4 Model 3: Full Model (All features)
model3 <- lm(Price_Numeric ~ RAM_GB + Storage_GB + Display_Size + 
               Has_Backlit + Has_TypeC + Has_Fingerprint + 
               Processor_i5 + Processor_i7 + Has_GPU, 
             data = train_data, na.action = na.exclude)
summary(model3)

# 6.5 Model Comparison on Test Data
# Function to calculate metrics (handles NA values)
calculate_metrics <- function(model, test_data, model_name) {
  # Predict only on rows with complete data
  test_complete <- test_data[complete.cases(test_data[, all.vars(formula(model))]), ]
  
  if(nrow(test_complete) == 0) {
    return(data.frame(
      Model = model_name,
      Train_R2 = NA,
      Adj_Train_R2 = NA,
      Test_R2 = NA,
      Test_RMSE_BDT = NA,
      Test_MAE_BDT = NA,
      Note = "No complete cases in test data"
    ))
  }
  
  predictions <- predict(model, newdata = test_complete, na.action = na.pass)
  actual <- test_complete$Price_Numeric
  
  # Remove any NA predictions
  valid_idx <- !is.na(predictions)
  predictions <- predictions[valid_idx]
  actual <- actual[valid_idx]
  
  if(length(actual) == 0) {
    return(data.frame(
      Model = model_name,
      Train_R2 = NA,
      Adj_Train_R2 = NA,
      Test_R2 = NA,
      Test_RMSE_BDT = NA,
      Test_MAE_BDT = NA,
      Note = "No valid predictions"
    ))
  }
  
  rmse <- sqrt(mean((actual - predictions)^2))
  mae <- mean(abs(actual - predictions))
  r2 <- 1 - sum((actual - predictions)^2) / sum((actual - mean(actual))^2)
  
  return(data.frame(
    Model = model_name,
    Train_R2 = round(summary(model)$r.squared, 4),
    Adj_Train_R2 = round(summary(model)$adj.r.squared, 4),
    Test_R2 = round(r2, 4),
    Test_RMSE_BDT = round(rmse, 0),
    Test_MAE_BDT = round(mae, 0),
    Test_Size = length(actual)
  ))
}

# Calculate metrics for all models
metrics_m1 <- calculate_metrics(model1, test_data, "RAM only")
metrics_m2 <- calculate_metrics(model2, test_data, "RAM + Storage")
metrics_m3 <- calculate_metrics(model3, test_data, "Full Model")

# Combine results
comparison_table <- bind_rows(metrics_m1, metrics_m2, metrics_m3)
print(comparison_table)

# Save comparison table
write.csv(comparison_table, "model_comparison.csv", row.names = FALSE)

# 6.6 Model Comparison using Information Criteria (AIC/BIC)
# CORRELATION HEATMAP
# ============================================================================

library(corrplot)
numeric_vars <- df_clean[, c("Price_Numeric", "RAM_GB", "Storage_GB", "Display_Size")]

cor_matrix <- cor(numeric_vars, use = "complete.obs")

# Print correlation matrix
cat("\n=== CORRELATION MATRIX ===\n")
print(round(cor_matrix, 3))

# Display heatmap
corrplot(cor_matrix, 
         method = "number", 
         type = "upper", 
         tl.col = "black", 
         tl.cex = 1.2, 
         number.cex = 1.2,
         title = "Correlation Matrix of Hardware Features", 
         mar = c(0, 0, 2, 0))

corrplot(cor_matrix, 
         method = "number", 
         type = "upper", 
         tl.col = "black", 
         tl.cex = 1.2, 
         number.cex = 1.2,
         title = "Correlation Matrix of Hardware Features", 
         mar = c(0, 0, 2, 0))

comparison_IC <- data.frame(
  Model = c("Model 1 (RAM only)", "Model 2 (RAM+Storage)", "Model 3 (Full)"),
  R_squared = c(summary(model1)$r.squared, summary(model2)$r.squared, summary(model3)$r.squared),
  Adj_R_squared = c(summary(model1)$adj.r.squared, summary(model2)$adj.r.squared, summary(model3)$adj.r.squared),
  AIC = c(AIC(model1), AIC(model2), AIC(model3)),
  BIC = c(BIC(model1), BIC(model2), BIC(model3))
)

print(comparison_IC)

# Interpretation
cat("Model 2 improvement over Model 1 (R²):", 
    round(comparison_IC$R_squared[2] - comparison_IC$R_squared[1], 4), "\n")
cat("Model 3 improvement over Model 2 (R²):", 
    round(comparison_IC$R_squared[3] - comparison_IC$R_squared[2], 4), "\n")

# Lower AIC/BIC indicates better model
best_AIC <- which.min(comparison_IC$AIC)
cat("\nBest model by AIC:", comparison_IC$Model[best_AIC], "\n")

# 6.7 VIF Test for Multicollinearity (Full Model)

# Remove rows with NA for VIF calculation
vif_data <- na.omit(train_data[, c("RAM_GB", "Storage_GB", "Display_Size", 
                                   "Has_Backlit", "Has_TypeC", "Has_Fingerprint", 
                                   "Processor_i5", "Processor_i7", "Has_GPU")])
if(nrow(vif_data) > 0) {
  vif_model <- lm(Price_Numeric ~ RAM_GB + Storage_GB + Display_Size + 
                    Has_Backlit + Has_TypeC + Has_Fingerprint + 
                    Processor_i5 + Processor_i7 + Has_GPU, 
                  data = vif_data)
  vif_values <- vif(vif_model)
  print(vif_values)
  
}

# ============================================================================
# 7. RESULTS VISUALIZATION

# 7.1 Actual vs Predicted Plot (Best Model)
test_data$Predicted <- predict(model3, newdata = test_data)

p6 <- ggplot(test_data, aes(x = Price_Numeric, y = Predicted)) +
  geom_point(alpha = 0.5, color = "darkblue", size = 2) +
  geom_abline(slope = 1, intercept = 0, color = "red", linetype = "dashed", size = 1) +
  labs(
    title = "Actual vs Predicted Laptop Prices (Full Model)",
    subtitle = paste("R² =", round(comparison_table$Test_R2[3], 3), 
                     "| RMSE =", format(comparison_table$Test_RMSE_BDT[3], big.mark = ","), "BDT"),
    x = "Actual Price (BDT)", 
    y = "Predicted Price (BDT)"
  ) +
  scale_x_continuous(labels = scales::comma) +
  scale_y_continuous(labels = scales::comma) +
  theme_minimal()

print(p6)
ggsave("plots/7_actual_vs_predicted.png", p6, width = 10, height = 8)
cat("Saved: plots/7_actual_vs_predicted.png\n")

# 7.2 Coefficient Plot (Feature Importance)
coef_data <- data.frame(
  Feature = c("RAM (GB)", "Storage (GB)", "Display (inch)", 
              "Backlit Keyboard", "USB Type-C", "Fingerprint",
              "Core i5", "Core i7", "Dedicated GPU"),
  Coefficient = coef(model3)[2:10],
  Lower = confint(model3)[2:10, 1],
  Upper = confint(model3)[2:10, 2],
  P_value = summary(model3)$coefficients[2:10, 4]
)

# Add significance stars
coef_data$Significance <- ifelse(coef_data$P_value < 0.001, "***",
                                 ifelse(coef_data$P_value < 0.01, "**",
                                        ifelse(coef_data$P_value < 0.05, "*", "ns")))

p7 <- ggplot(coef_data, aes(x = reorder(Feature, Coefficient), y = Coefficient)) +
  geom_point(size = 3, aes(color = Significance)) +
  geom_errorbar(aes(ymin = Lower, ymax = Upper), width = 0.2) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray50") +
  coord_flip() +
  labs(
    title = "Impact of Hardware Features on Laptop Price",
    subtitle = "Error bars show 95% confidence intervals | *** p < 0.001, ** p < 0.01, * p < 0.05",
    x = "Feature", 
    y = "Price Impact (BDT)"
  ) +
  scale_y_continuous(labels = scales::comma) +
  theme_minimal()

print(p7)
ggsave("plots/8_coefficient_plot.png", p7, width = 10, height = 7)
cat("Saved: plots/8_coefficient_plot.png\n")

# 7.3 Residual Diagnostics
p8 <- ggplot(train_data, aes(x = fitted(model3), y = resid(model3))) +
  geom_point(alpha = 0.5, color = "darkred") +
  geom_hline(yintercept = 0, color = "blue", linetype = "dashed") +
  geom_smooth(se = FALSE, color = "red", method = "loess") +
  labs(
    title = "Residual Plot: Checking Homoscedasticity",
    x = "Fitted Values (BDT)", 
    y = "Residuals (BDT)"
  ) +
  scale_x_continuous(labels = scales::comma) +
  theme_minimal()

print(p8)
ggsave("plots/9_residual_plot.png", p8, width = 10, height = 6)
cat("Saved: plots/9_residual_plot.png\n")

# 7.4 Q-Q Plot for Normality Check
png("plots/10_qq_plot.png", width = 800, height = 600)
qqnorm(resid(model3), main = "Q-Q Plot: Normality of Residuals")
qqline(resid(model3), col = "red", lwd = 2)
dev.off()
cat("Saved: plots/10_qq_plot.png\n")

# 7.5 Price Range by Feature Presence
feature_impact <- df_clean %>%
  group_by(Has_GPU) %>%
  summarise(
    Count = n(),
    Mean_Price = mean(Price_Numeric),
    Median_Price = median(Price_Numeric)
  )

cat("\n--- GPU Impact on Price ---\n")
print(feature_impact)

# ============================================================================
# 8. FINAL SUMMARY

cat("• Best Model R²:", comparison_table$Test_R2[3], "on test data\n")
cat("• RMSE:", format(comparison_table$Test_RMSE_BDT[3], big.mark = ","), "BDT\n")
cat("• Most important feature: RAM (", 
    round(coef_data$Coefficient[coef_data$Feature == "RAM (GB)"], 0), "BDT per GB)\n")
cat("• Core i7 premium:", 
    format(round(coef_data$Coefficient[coef_data$Feature == "Core i7"], 0), big.mark = ","), "BDT\n")
